#include <stdio.h>
#include <math.h>
#include "IIR.h"
#include "Input.h"
#include "IIR_Output_Ref.h"
#include "csl_tsc.h"

#include<c6x.h>

//#pragma DATA_SECTION (Input,".mysect");

//#pragma DATA_SECTION (Output,".mysect");

#define DSP_CORE_FREQUENCY 1,400000000
#define CYCLE_PERIOD 714e-8
#define N 800

float output[800];
float IIR(float xn);
float compare;
unsigned int compare_NOT_OK;
unsigned int compare_OK;



void main (void)
{
	unsigned long long int start,end,nb_cycle,overhead;
	double execution_time;
	int i;
	compare_OK = 0;
	compare_NOT_OK = 0;

	_CSL_tscEnable();

	start=_CSL_tscRead();

	end=_CSL_tscRead();

	overhead=end-start;

	printf("IIR Start\n");
	start =_CSL_tscRead ();


	for(i=0; i < 800; i++){
		output[i] = IIR(Input[i]);

	}
	end=_CSL_tscRead();

	nb_cycle =end-start-overhead;
	printf("IIR Finish\n");
	execution_time = (double)nb_cycle * CYCLE_PERIOD;

	printf("Execution time: %lf seconds\n", execution_time);





	/** Verification **********************************/

	for (i=0;i<800;i++)
	{
	       compare = abs(output[i] - IIR_Output_Ref[i]);


	       if(compare <= 0.01)
	       {
	       	compare_OK ++ ;
	       }
	       else
	       {
	       	compare_NOT_OK ++;
	       }
	}
	printf(" Compare OK     : %d \n",compare_OK);
	printf(" Compare NOT_OK : %d \n",compare_NOT_OK);
}

float IIR(float xn)
{
	int i;

	X_BUF[0]= xn;
	float y=X_BUF[0]*b_coeff[0];
	for (i=1;i<=7;i++)
		{
		y+=X_BUF[i]*b_coeff[i]-Y_BUF[i]*a_coeff[i];
		}
	Y_BUF[0]=y;
	for(i=7;i>=1;i--)
		{
		X_BUF[i]=X_BUF[i-1];
		Y_BUF[i]=Y_BUF[i-1];
		}
	return y ;
}
